% hitung poin kartu
hitung_poin_kartu(kartu(hitam, _), 20) :- !.
hitung_poin_kartu(kartu(_, skip), 10) :- !.
hitung_poin_kartu(kartu(_, reverse), 10) :- !.
hitung_poin_kartu(kartu(_, drawtwo), 10) :- !.
hitung_poin_kartu(kartu(_, Angka), Angka) :- integer(Angka), !.

% Rekursi menghitung total poin 1 list kartu
hitung_poin_tangan([], 0).
hitung_poin_tangan([Kartu|Sisa], Total) :-
    hitung_poin_kartu(Kartu, Poin),
    hitung_poin_tangan(Sisa, TotalSisa),
    Total is Poin + TotalSisa.

% Rekursi memetakan list pemain ke poin masing-masing (format: Poin-Nama)
hitung_semua_poin([], []).
hitung_semua_poin([Pemain|SisaPemain], [Poin-Pemain | SisaSkor]) :-
    kartu_pemain(Pemain, ListKartu),
    hitung_poin_tangan(ListKartu, Poin),
    hitung_semua_poin(SisaPemain, SisaSkor).

% Pengecekan status Game Over
cekEndGame :-
    kartu_pemain(Pemenang, []), !, % Akan dieksekusi HANYA jika ada pemain dengan kartu []
    nl, write('==========================================='), nl,
    write(' PERMAINAN SELESAI! PEMENANGNYA: '), write(Pemenang), nl,
    write('==========================================='), nl,
    
    urutan_pemain(SemuaPemain),
    hitung_semua_poin(SemuaPemain, ListSkor),
    keysort(ListSkor, SkorTerurut), % keysort otomatis urut dari poin terkecil
    
    nl, write('Peringkat Akhir (Berdasarkan Poin Terkecil):'), nl,
    print_leaderboard(SkorTerurut, 1),
    halt. % Matikan sesi GNU Prolog karena game kelar

cekEndGame. % Jika blm ada yang kosong, skip dan lanjut game

% Ngeprint Leaderboard
print_leaderboard([], _).
print_leaderboard([Poin-Pemain|Sisa], Peringkat) :-
    write(Peringkat), write('. '), write(Pemain), write(' - '), write(Poin), write(' poin'), nl,
    NextPeringkat is Peringkat + 1,
    print_leaderboard(Sisa, NextPeringkat).